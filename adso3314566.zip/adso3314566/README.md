# AD3314566

## Analisis y Desarrollo de Software

### Centro de Procesos Industriales y Construccion

*Regional Caldas*

---

| ID | THEME  | Description                              |
|--- |---          |---                                   |
|01  | Emmet       |Work Flow - Markup & Styling          |
|02  | HTML        |Strcture  - Hypertext Markup Language |
|03  | Css         |Look & Fell - Cascading Style Sheets  |
|04  | Javasacript |Behavior - Programing Languege        |

![Mila](https://adso3314566-alpha.vercel.app/src/imgs/mifotooo.jpg)

[ADSO Files DRIVE](https://tinyurl.com/wnkk334u)

[VERCEL URL](https://adso3314566-alpha.vercel.app/)